package io.fp.bmiCalculator;

import java.util.ArrayList;

public class HealthCheck {

  private ArrayList<Calculation> history = new ArrayList<>();

  public String executeHealthCheck(double weight, double height) throws CategoryException, BMICalculatorException {
    double bmi = BMICalculator.computeBMI(weight, height);
    Calculation calculation = new Calculation(bmi, Category.getCategory(bmi));
    history.add(calculation);
    return calculation.toString();
  }

  public int getNumberOfCalculations() {
    return history.size();
  }

  public void printHistory() {
    System.out.println("Your History: ");
    for (Calculation calculations : history) {
      System.out.println(calculations.toString() + "\n");
    }
  }

  public void printCategoryStatistics() {
    for (Category category : Category.values()) {
      int count = 0;
      for (Calculation calculations : history) {
        if (calculations.getCategory().equals(category)) {
          count++;
        }
      }
      System.out.println("[" + category + ": " + count + "]");
    }
  }

  public void printAverageBMI() {
    double avg = 0;
    for (Calculation calculations : history) {
      avg += calculations.getBmi();
    }
    System.out.println("The average BMI was: " + avg / history.size());
  }

}
