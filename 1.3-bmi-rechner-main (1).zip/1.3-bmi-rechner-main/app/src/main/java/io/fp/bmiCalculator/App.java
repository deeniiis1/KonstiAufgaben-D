package io.fp.bmiCalculator;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        HealthCheck healthCheck = new HealthCheck();
        try (Scanner scanner = new Scanner(System.in)) {
            
            System.out.println("------ Start Health Checks ------\n");
            boolean continueHealtCheck = true;
            while (continueHealtCheck) {
                System.out.println("Please enter your height in meters:");
                String heightString = scanner.nextLine();
                System.out.println("Please enter your weight in kilogramms:");
                String weightString = scanner.nextLine();

                try {
                    System.out.println(healthCheck.executeHealthCheck(Double.parseDouble(weightString),
                            Double.parseDouble(heightString)));
                    System.out.println("Do you want to see your history? (Y/N)");
                    String answer = scanner.nextLine();
                    if (answer.equals("Y")) {
                        healthCheck.printHistory();
                    }
                    System.out.println("Do you want to execue another health-check? (Y/N)");
                    answer = scanner.nextLine();
                    if (!answer.equals("Y")) {
                        healthCheck.printAverageBMI();
                        System.out.println("Category-Statistic: ");
                        healthCheck.printCategoryStatistics();
                        continueHealtCheck = false;
                    }
                } catch (NumberFormatException | CategoryException | BMICalculatorException e) {
                    System.out.println(e.getMessage());
                }

            }
        }

    }

}