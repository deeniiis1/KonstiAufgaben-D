# Weihnachtsaufgabe
## Wunschliste (Listen, Unchecked Exception)
Jedes Kind schreibt eine Wunschliste für den Weihnachtsmann.
Erstellen Sie die Klasse Wishlist mit dem Attribut **wishes** vom Typ Liste (Wünsche werden als String angegeben).
Folgendes soll mit der Wishlist möglich sein:
- Wünsche hinzuzufügen. Es sollen maximal fünf Wünsche auf die Liste passen. Wenn ein weiterer Wunsch hinzugefügt wird soll eine unchecked Exception vom Typ NoMoreSpaceOnPaper geworfen werden.
- Wünsche zu ersetzen mittels Position
- Eine Auswahl an Wünschen als Rückgabewert (Die Anzahl soll parametrisiert sein und welche Reihenfolge ist Ihre Entscheidung).

## SantasReindeer (Basics, Sets, Checked Exception, Enum)
Rentiere ziehen den Schlitten des Weihnachtsmanns.
Erstellen sie zunächst das Enum Weather mit den Werten Foggy und Clear.
Erstellen Sie nun die Klasse Reindeer, welches die Attribute **name** und **flyingWeathers** hat. Dieses gewöhnliche Rentier hat als flyingWeathers den Wert **Clear** vorbelegt.
Erstellen Sie außerdem die Klasse RedNosedReindeer, welche von Reindeer erbt, und für flyingWeathers die Werte Clear UND Foggy hat.
Erstellen Sie nun die Klasse SantasReindeer, welche ein Attribut **allReindeer** vom Typ Set hat. 
Folgendes soll mit SantasReindeer möglich sein:
- Hinzufügen eines Reindeer. Dabei soll ein Reindeer über seinen Namen eindeutig identifizierbar sein.
- Das Kommando zum Fliegen. Dabei soll das jetzige Wetter als Parameter übergeben werden und dann ermittelt werden, ob ein Rentier eingebunden ist, das in dem Wetter fliegen kann. Kann keines der Rentiere in dem Wetter fliegen soll eine checked Exception vom Typ MissingReindeerForWeatherException geworfen werden. Außerdem soll geprüft werden ob mindestens acht Rentiere eingebunden sind. Wenn nicht soll eine checken Exception vom Typ NotEnoughReindeerException geworfen werden.

## SantasList (Maps, Enum)
Der Weihnachtsmann kategorisiert Kinder in Naughty oder Nice ein.
Estellen Sie die Klasse SantasList mit den Attributen **naughtyOrNice** vom Typ Map.
Erstellen Sie außerdem ein Enum mit den Werten Naughty und Nice und dem Attribut **amountOfPresents** hinzu, wobei Naughty den Wert 1 und Nice den Wert 3 bekommt. 
Folgendes soll mit SantasList möglich sein:
- Einen Namen mit Kennzeichnung Naughty oder Nice eintragen
- Die Kennzeichnung Naughty or Nice für einen Namen hin- und herwechseln
- Abrufen der Anzahl von Geschenken für einen Namen

## Route (Queues, Comparable)
Die Route des Weihnachtsmanns soll ihm beim Ausfliegen der Geschenke helfen.
Erstellen sie die Klasse Route mit dem Attribut **addresses** vom Typ Queue, welche Objekte vom Typ Address annimmt. Erstellen Sie außerdem die Klasse Address, welche die Attribute **street** und **distanceToNorthPoleInKM** hat.
Folgendes soll mit Route möglich sein:
- Hinzufügen von Adressen, welche nach Entfernung zum Nordpol sortiert sind (aufsteigend). Ist die Entfernung von zwei Adressen gleich, soll dann die Straße als Vergleichskriterium genutzt werden (alphabetisch).
- Abrufen vom nächsten Stopp. Wenn keine Stopps mehr eingeplant sind soll stattdessen die Adresse des Weihnachtsmanns zurückgegeben werden (Die können Sie sich ausdenken)

## Wrapping (Generics)
Der Weihnachtsmann möchte Geschenke schön einpacken.
Erstellen Sie die abstrakte Klasse Gift mit den Attributen **to** und **name**.
Erstellen Sie nun die generische Klasse Wrapping, welche nur Unterklassen von Gift zulässt.
Folgendes soll mit Wrapping möglich sein:
- Eine Unterklasse von Gift einpacken und so eine neue Instanz von Wrapping mit dem jeweiligen Typ erzeugen
- Ein eingepacktes Gift wieder auspacken
- Eine Geschenkkarte mit folgendem Text ausgeben: "To [to], enjoy your [name]. Merry christmas, Santa"