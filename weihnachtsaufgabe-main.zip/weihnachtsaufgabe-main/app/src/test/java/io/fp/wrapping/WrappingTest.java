package io.fp.wrapping;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class WrappingTest {
    
    @Test
    void should_return_giftmessage_with_name() {
        Wrapping<Toy> wrappedToy = Wrapping.wrap(new Toy("Tibbers"), "Annie");

        String card = wrappedToy.card();

        assertEquals("To Annie, enjoy your Tibbers. Merry christmas, Santa", card);
    }

    @Test
    void should_return_wrapped_toy() {
        Toy toy = new Toy("Tibbers");
        Wrapping<Toy> wrappedToy = Wrapping.wrap(toy, "Annie");

        Toy unwrappedToy = wrappedToy.unwrap();

        assertEquals(toy, unwrappedToy);
    }

}
