package io.fp.santasreindeer;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class SantasReindeerTest {

    @Test
    void should_fly_with_8_reindeer_in_clear_weather() throws NotEnoughReindeerException, NoReindeerForWeather {
        SantasReindeer santasReindeer =  new SantasReindeer();
        santasReindeer.attach(new Reindeer("Donner"));
        santasReindeer.attach(new Reindeer("Blitzen"));
        santasReindeer.attach(new Reindeer("Cupid"));
        santasReindeer.attach(new Reindeer("Comet"));
        santasReindeer.attach(new Reindeer("Dasher"));
        santasReindeer.attach(new Reindeer("Dancer"));
        santasReindeer.attach(new Reindeer("Prancer"));
        santasReindeer.attach(new Reindeer("Vixen"));

        assertFalse(santasReindeer.isFlying());
        santasReindeer.fly(Weather.CLEAR);

        assertTrue(santasReindeer.isFlying());
    }

    @Test
    void should_throw_exception_when_less_than_8_unique_reindeer() throws NotEnoughReindeerException, NoReindeerForWeather {
        SantasReindeer santasReindeer =  new SantasReindeer();
        santasReindeer.attach(new Reindeer("Donner"));
        santasReindeer.attach(new Reindeer("Blitzen"));
        santasReindeer.attach(new Reindeer("Cupid"));
        santasReindeer.attach(new Reindeer("Comet"));
        santasReindeer.attach(new Reindeer("Dasher"));
        santasReindeer.attach(new Reindeer("Dancer"));
        santasReindeer.attach(new Reindeer("Prancer"));
        santasReindeer.attach(new Reindeer("Prancer"));

        assertFalse(santasReindeer.isFlying());
        assertThrows(NotEnoughReindeerException.class, () -> santasReindeer.fly(Weather.CLEAR));
    }
    
    @Test
    void should_not_fly_with_less_than_8_reindeer() throws NotEnoughReindeerException, NoReindeerForWeather {
        SantasReindeer santasReindeer =  new SantasReindeer();
        santasReindeer.attach(new Reindeer("Donner"));
        santasReindeer.attach(new Reindeer("Blitzen"));
        santasReindeer.attach(new Reindeer("Cupid"));
        santasReindeer.attach(new Reindeer("Comet"));
        santasReindeer.attach(new Reindeer("Dasher"));
        santasReindeer.attach(new Reindeer("Dancer"));
        santasReindeer.attach(new Reindeer("Prancer"));

        assertFalse(santasReindeer.isFlying());
        assertThrows(NotEnoughReindeerException.class, () -> santasReindeer.fly(Weather.CLEAR));
        assertFalse(santasReindeer.isFlying());
    }

    @Test
    void should_only_fly_with_red_nosed_reindeer_in_foggy_weather() throws NotEnoughReindeerException, NoReindeerForWeather {
        SantasReindeer santasReindeer =  new SantasReindeer();
        santasReindeer.attach(new Reindeer("Donner"));
        santasReindeer.attach(new Reindeer("Blitzen"));
        santasReindeer.attach(new Reindeer("Cupid"));
        santasReindeer.attach(new Reindeer("Comet"));
        santasReindeer.attach(new Reindeer("Dasher"));
        santasReindeer.attach(new Reindeer("Dancer"));
        santasReindeer.attach(new Reindeer("Prancer"));
        santasReindeer.attach(new Reindeer("Vixen"));

        assertFalse(santasReindeer.isFlying());
        assertThrows(NoReindeerForWeather.class, () -> santasReindeer.fly(Weather.FOGGY));
        assertFalse(santasReindeer.isFlying());

        santasReindeer.attach(new RedNosedReindeer("Rudolph"));

        assertFalse(santasReindeer.isFlying());
        santasReindeer.fly(Weather.FOGGY);
        assertTrue(santasReindeer.isFlying());
    }
    
}
