package io.fp.wishlist;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class WishlistTest {
    
    Wishlist wishlist =  new Wishlist();

    @BeforeEach
    void setUp() {
        wishlist.addWish("Fire truck");
        wishlist.addWish("Doll");
        wishlist.addWish("iPhone");
        wishlist.addWish("iPad");
        wishlist.addWish("Nintendo Switch");
    }

    @Test
    void should_throw_exception_after_five_wishes() {
        assertThrows(NoMoreSpaceOnPaperException.class, () -> wishlist.addWish("House"));
    }

    @Test
    void should_retrieve_amount_of_wishes() {
       List<String> wishes = wishlist.chooseWishes(3); 

       List<String> expectedWishes = List.of("Fire truck", "Doll", "iPhone");
       assertIterableEquals(expectedWishes, wishes);
    }

    @Test
    void should_replace_wish() {
        wishlist.replaceWishAt(0, "Lego");

        String wish = wishlist.chooseWishes(1).get(0);

        assertEquals("Lego", wish);
    }

}
