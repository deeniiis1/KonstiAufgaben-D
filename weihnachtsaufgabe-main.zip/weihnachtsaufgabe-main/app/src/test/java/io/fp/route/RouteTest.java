package io.fp.route;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class RouteTest {
    
    @Test
    void should_return_address_nearest_to_north_pole() {
        Route route =  new Route();
        route.add(new Address("City Castle", 2500));
        route.add(new Address("Snow Street 1", 50));
        route.add(new Address("Beach Boulevard", 5000));

        Address nextStop = route.getNextStop();

        Address expectedAddress = new Address("Snow Street 1", 50);
        assertEquals(expectedAddress, nextStop);

        expectedAddress = new Address("City Castle", 2500);
        assertEquals(expectedAddress, route.getNextStop());

        expectedAddress = new Address("Beach Boulevard", 5000);
        assertEquals(expectedAddress, route.getNextStop());
    }

    @Test
    void should_return_santas_address_if_no_more_addresses_available() {
        Route route =  new Route();

        Address expectedAddress = new Address("Santas Home", 0);
        assertEquals(expectedAddress, route.getNextStop());
    }

}
