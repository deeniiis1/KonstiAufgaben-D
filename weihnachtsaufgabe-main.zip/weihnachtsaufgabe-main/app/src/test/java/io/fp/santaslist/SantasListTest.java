package io.fp.santaslist;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SantasListTest {
    
    @Test
    void should_return_three_presents_for_nice_child() {
        SantasList santasList = new SantasList();
        santasList.add("Uther", SantasCategory.NICE);

        int amountOfPresents = santasList.getAmountOfPresents("Uther");

        assertEquals(3, amountOfPresents);
    }

    @Test
    void should_return_one_present_for_naughty_child() {
        SantasList santasList = new SantasList();
        santasList.add("Arthas", SantasCategory.NAUGHTY);

        int amountOfPresents = santasList.getAmountOfPresents("Arthas");

        assertEquals(1, amountOfPresents);
    }

    @Test
    void should_be_able_to_toggle_between_naughty_and_nice() {
        SantasList santasList = new SantasList();
        santasList.add("Arthas", SantasCategory.NAUGHTY);

        int amountOfPresents = santasList.getAmountOfPresents("Arthas");
        assertEquals(1, amountOfPresents);

        santasList.toggle("Arthas");
        int newAmountOfPresents = santasList.getAmountOfPresents("Arthas");
        assertEquals(3, newAmountOfPresents);

        santasList.toggle("Arthas");
        newAmountOfPresents = santasList.getAmountOfPresents("Arthas");
        assertEquals(1, newAmountOfPresents);
    }

}
