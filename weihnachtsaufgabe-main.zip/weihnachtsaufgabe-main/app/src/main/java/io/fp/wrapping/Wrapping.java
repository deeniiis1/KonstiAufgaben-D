package io.fp.wrapping;

public class Wrapping<T extends Gift> {

    private T gift;
    private String to;

    private Wrapping(T gift, String childsName) {
        this.gift = gift;
        this.to = childsName;
    }

    public static <T extends Gift> Wrapping<T> wrap(T gift, String childsName) {
        return new Wrapping<>(gift, childsName);
    }

    public String card() {
        String card = String.format("To %s, enjoy your %s. Merry christmas, Santa", to, gift.getName()); 
        System.out.println(card);
        return card;
    }

    public T unwrap() {
        return gift;
    }

}
