package io.fp.santaslist;

import java.util.HashMap;
import java.util.Map;

public class SantasList {

    private Map<String, SantasCategory> naughtyOrNice = new HashMap<>();

    public void add(String childsName, SantasCategory category) {
        naughtyOrNice.put(childsName, category);
    }

    public int getAmountOfPresents(String string) {
        return naughtyOrNice.get(string).getAmountOfPresents();
    }

    public void toggle(String childsName) {
        naughtyOrNice.computeIfPresent(childsName, (k,v) -> SantasCategory.NICE.equals(v) ? SantasCategory.NAUGHTY : SantasCategory.NICE);
    }

}
