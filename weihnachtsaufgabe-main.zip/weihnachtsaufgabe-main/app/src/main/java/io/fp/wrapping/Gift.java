package io.fp.wrapping;

public abstract class Gift {

    private String name;

    public Gift(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
