package io.fp.santasreindeer;

public class RedNosedReindeer extends Reindeer {

    protected RedNosedReindeer(String name) {
        super(name, Weather.CLEAR, Weather.FOGGY);
    }


}
