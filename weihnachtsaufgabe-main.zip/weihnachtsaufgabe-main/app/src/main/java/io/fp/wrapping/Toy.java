package io.fp.wrapping;

public class Toy extends Gift {

    public Toy(String name) {
        super(name);
    }

}
