package io.fp.wishlist;

import java.util.ArrayList;
import java.util.List;

public class Wishlist {

    private List<String> wishes = new ArrayList<>();

    public void addWish(String wish) {
        if(wishes.size() == 5) {
            throw new NoMoreSpaceOnPaperException();
        }
        wishes.add(wish);
    }

    public List<String> chooseWishes(int amountOfGrantedWishes) {
        return wishes.subList(0, amountOfGrantedWishes);
    }

    public void replaceWishAt(int place, String newWish) {
        wishes.set(place, newWish);
    }

}
