package io.fp.route;

public class Address implements Comparable<Address>{

    private int distanceToNorthPoleInKM;
    private String street;

    public Address(String street, int distanceToNorthPoleInKM) {
        this.street = street;
        this.distanceToNorthPoleInKM = distanceToNorthPoleInKM;
    }

    @Override
    public int compareTo(Address otherAddress) {
        int compareValue = Integer.valueOf(distanceToNorthPoleInKM).compareTo(otherAddress.distanceToNorthPoleInKM);
        if(compareValue == 0) {
            compareValue = street.compareTo(otherAddress.street);
        }
        return compareValue;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + distanceToNorthPoleInKM;
        result = prime * result + ((street == null) ? 0 : street.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Address other = (Address) obj;
        if (distanceToNorthPoleInKM != other.distanceToNorthPoleInKM)
            return false;
        if (street == null) {
            if (other.street != null)
                return false;
        } else if (!street.equals(other.street))
            return false;
        return true;
    }

    

}
