package io.fp.santasreindeer;

public class NotEnoughReindeerException extends Exception {

}
