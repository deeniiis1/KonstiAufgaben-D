package io.fp.wishlist;

public class NoMoreSpaceOnPaperException extends RuntimeException{

}
