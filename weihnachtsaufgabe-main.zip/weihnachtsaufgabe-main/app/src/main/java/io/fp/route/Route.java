package io.fp.route;

import java.util.PriorityQueue;
import java.util.Queue;

public class Route {

    Queue<Address> route =  new PriorityQueue<>();

    public void add(Address address) {
        route.add(address);
    }

    public Address getNextStop() {
        if(route.peek() == null) {
            return new Address("Santas Home", 0);
        }
        return route.poll();
    }

}
