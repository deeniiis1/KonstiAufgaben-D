package io.fp.santaslist;

public enum SantasCategory {
    NICE(3), NAUGHTY(1);

    private int amountOfPresents;

    private SantasCategory(int amountOfPresents) {
        this.amountOfPresents  = amountOfPresents;
    }

    public int getAmountOfPresents() {
        return amountOfPresents;
    }

}
