package io.fp.santasreindeer;

public enum Weather {
    FOGGY, CLEAR
}
