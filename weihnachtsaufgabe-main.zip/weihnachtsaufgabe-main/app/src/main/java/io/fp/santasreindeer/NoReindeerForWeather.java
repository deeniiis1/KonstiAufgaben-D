package io.fp.santasreindeer;

public class NoReindeerForWeather extends Exception{

}
