package io.fp.santasreindeer;

import java.util.ArrayList;
import java.util.List;

public class Reindeer {

    private String name;
    private List<Weather> flyingWeathers = new ArrayList<>();

    public Reindeer(String name) {
        this(name, Weather.CLEAR);
    }

    protected Reindeer(String name, Weather... flyingWeathers) {
        this.name = name;
        this.flyingWeathers.addAll(List.of(flyingWeathers));
    }

    public boolean canFly(Weather currentWeather) {
        return flyingWeathers.contains(currentWeather);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Reindeer other = (Reindeer) obj;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        return true;
    }

}
