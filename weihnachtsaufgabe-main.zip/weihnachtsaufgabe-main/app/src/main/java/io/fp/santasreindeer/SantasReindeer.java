package io.fp.santasreindeer;

import java.util.HashSet;
import java.util.Set;

public class SantasReindeer {

    private Set<Reindeer> reindeer =  new HashSet<>();
    private boolean flying = false;

    public void attach(Reindeer reindeer) {
        this.reindeer.add(reindeer);
    }

    public void fly(Weather currentWeather) throws NotEnoughReindeerException, NoReindeerForWeather {
        if(reindeer.size() < 8) {
            throw new NotEnoughReindeerException();
        }
        
        boolean canFly =  false;
        for(Reindeer r : reindeer) {
            if(r.canFly(currentWeather)) {
                canFly = true;
            }
        }

        if(canFly) {
            flying = true;
        }
        else{
            throw new NoReindeerForWeather();
        }
    }

    public boolean isFlying() {
        return flying;
    }

}
