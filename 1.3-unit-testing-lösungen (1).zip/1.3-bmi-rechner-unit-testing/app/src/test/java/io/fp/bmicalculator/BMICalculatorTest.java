package io.fp.bmicalculator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class BMICalculatorTest {
   
    @Test
    void testCalculateBMIException(){
        assertThrows(BMICalculatorException.class, ()->{
            BMICalculator.computeBMI(300, 3);
        });
    }

    @Test
    void testCalculateBMI() throws BMICalculatorException{  
        //BMI-value for 1.8m & 75Kg
        double expectedBMI = 23.15;

        double calculatedBMI = (double)Math.round(BMICalculator.computeBMI(75,1.8) * 100) / 100;   
        assertEquals(expectedBMI,  calculatedBMI);
    }
}
