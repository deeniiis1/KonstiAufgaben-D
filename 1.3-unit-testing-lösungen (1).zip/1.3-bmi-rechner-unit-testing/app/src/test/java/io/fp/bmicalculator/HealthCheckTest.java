package io.fp.bmicalculator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;

public class HealthCheckTest {

    HealthCheck healthCheck;
    
    @BeforeEach
    void setUp(){
        healthCheck = new HealthCheck();
    }

    @Test
    void testHealthCheckExecution() throws CategoryException, BMICalculatorException{
        //Vorgegebene Berechnung bei einer größe von 1.75m und 60Kg
        Calculation calculation = new Calculation(19.59, Category.HEALTHY); 
        assertEquals(calculation.toString(), healthCheck.executeHealthCheck(60, 1.75));                
    }

    @Test
    void testHealthCheckHistory() throws CategoryException, BMICalculatorException{
        int currentNumberOfCalculations = healthCheck.getNumberOfCalculations();
        healthCheck.executeHealthCheck(92, 1.9);
        assertEquals(currentNumberOfCalculations+1, healthCheck.getNumberOfCalculations());
    }
}
