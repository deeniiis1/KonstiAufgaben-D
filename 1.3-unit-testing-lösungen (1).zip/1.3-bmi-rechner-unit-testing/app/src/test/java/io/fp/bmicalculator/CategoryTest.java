package io.fp.bmicalculator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;


public class CategoryTest {
    
    @Test
    void testGetCategoryLowerBoundary(){
        assertThrows(CategoryException.class, ()->{
            Category.getCategory(8);
        });
    }

    @Test
    void testGetCategoryUpperBoundary(){
        assertThrows(CategoryException.class, ()->{
            Category.getCategory(101);
        });
    }

    @Test
    void testGetCategoryUnderweight(){
        assertEquals(Category.UNDERWEIGHT,Category.getCategory(16));
    }

    @Test
    void testGetCategoryHealthy(){
        assertEquals(Category.HEALTHY,Category.getCategory(20));
    }

    @Test
    void testGetCategoryOverweight(){
        assertEquals(Category.OVERWEIGHT,Category.getCategory(26));
    }

    @Test
    void testGetCategoryObese(){
        assertEquals(Category.OBESE,Category.getCategory(32));
    }
}
