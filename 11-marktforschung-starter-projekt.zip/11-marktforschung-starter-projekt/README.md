# 1.11 Marktforschung

Heute bauen wir ein Marktforschungstool, welches Funktionen anbietet um Produkte auszuwerten. </br>

**Ziel: Üben der Streams API (stream(), map(), filter(), collect(), foreach())**

*Vorgehen: Es sind bereits einige Tests in MarktforschungTest vorgegeben. Diese sollen sie nicht verändern. Führen sie erst den Test aus, implementieren sie dann bis er grün ist und wiederholen das für jeden Test*

- a) Implementieren sie die Methode **public List<String> getProduktNamen()**. </br>
Diese Methode soll zunächst einmal alle Namen der Produkte in der Liste **produkte* zurückgeben. Nutzen sie hierfür .stream().map(...) um die Produkte in Namen umzuwandeln und dann *.collect(Collectors.toList())* um sie zu einer Liste zusammenzufassen, welche sie dann als Ergebnis zurückgeben.

- b) Implementieren sie die Methode **public List<Double> getUmsaetze**. </br>
Diese Methode soll dem Anwender eine Liste geben, welche alle einzelnen Umsätze der Produkte enthält. Hierfür nutzen sie wieder .stream().map(...), um die Produkte in einen Umsatz umzuwandeln. Den Umsatz berechnen sie mit *getPreis()\*getVerkaufteMenge()*. Dann sammeln sie die berechneten Umsätze wieder mit *.collect()* ein.

- c) Implementieren sie die Methode **public List<Produkt> findProdukte(String zeichenImName)**. </br>
Diese Methode soll dem Anwender eine Suche über die Produkte ermöglichen. Wenn er einen Teil des Produktnamens eingibt, soll er als Ergebnis eine Liste aller Produkte bekommen, die diesen String enthalten. Nutzen sie hierfür die *.stream().filter(...)* Methode. 

- d) Implementieren sie die Methode **public List<String> getProduktNamenMitVerkaufterMengeKleiner(int verkaufteMenge)**. </br>
Diese Methode soll es dem Anwender ermöglichen eine Liste von Produktnamen zu bekommen, welche weniger als eine bestimmte Menge verkauft wurden.

- e) Zuletzt nutzen sie nun in der App.java das Objekt **marktforschung** um die dortige Frage zu beantworten und das Ergebnis mit *.foreach(produkt -> System.out.println(produkt))* auf der Konsole
auszugeben.