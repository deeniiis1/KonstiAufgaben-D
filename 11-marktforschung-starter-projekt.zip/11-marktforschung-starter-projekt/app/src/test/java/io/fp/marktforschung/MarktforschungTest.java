package io.fp.marktforschung;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MarktforschungTest {
    
    Marktforschung marktforschung;

    @BeforeEach
    void setUp() {
        marktforschung = new Marktforschung();
        marktforschung.addProdukt(new Produkt("Laptop", 1200.0, 50));
        marktforschung.addProdukt(new Produkt("Smartphone", 800.0, 120));
        marktforschung.addProdukt(new Produkt("Tablet", 400.0, 30));
        marktforschung.addProdukt(new Produkt("Smartwatch", 150.0, 80));
        marktforschung.addProdukt(new Produkt("Headphones", 100.0, 200));
    }

    @Test
    void should_get_all_product_names() {
        List<String> produktNamen = marktforschung.getProduktNamen();

       List<String> expectedProduktNamen = List.of("Laptop", "Smartphone", "Tablet", "Smartwatch", "Headphones"); 
       assertEquals(expectedProduktNamen, produktNamen);
    }

    @Test
    void should_get_revenues() {
        List<Double> umsaetze  = marktforschung.getUmsaetze();

        List<Double> expectedUmsaetze = List.of(60000.00, 96000.00, 12000.00, 12000.00, 20000.00);
        assertEquals(expectedUmsaetze, umsaetze);
    }
        @Test
    void should_find_product_by_string_search() {
        List<Produkt> gefundeneProdukte = marktforschung.findProdukte("Smart");

        List<String> expectedGefundeneProdukte = List.of("Smartphone", "Smartwatch");
        assertEquals(2, gefundeneProdukte.size());
        assertEquals(expectedGefundeneProdukte.get(0), gefundeneProdukte.get(0).getName());
        assertEquals(expectedGefundeneProdukte.get(1), gefundeneProdukte.get(1).getName());
    }

    @Test
    void should_get_name_of_products_that_have_sold_less_than_120_units() {
        List<String> produktNamen = marktforschung.getProduktNamenMitVerkaufterMengeKleiner(120);

        List<String> expectedProduktNamen = List.of("Laptop", "Tablet", "Smartwatch");
        assertEquals(expectedProduktNamen, produktNamen);
    }

}
