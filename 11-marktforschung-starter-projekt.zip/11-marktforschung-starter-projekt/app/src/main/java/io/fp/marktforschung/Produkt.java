package io.fp.marktforschung;

class Produkt {
    private String name;
    private double preis;
    private int verkaufteMenge;

    public Produkt(String name, double preis, int verkaufteMenge) {
        this.name = name;
        this.preis = preis;
        this.verkaufteMenge = verkaufteMenge;
    }

    public String getName() {
        return name;
    }

    public double getPreis() {
        return preis;
    }

    public int getVerkaufteMenge() {
        return verkaufteMenge;
    }

}

