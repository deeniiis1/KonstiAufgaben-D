package io.fp.marktforschung;

import java.util.ArrayList;
import java.util.List;

public class Marktforschung {

    private List<Produkt> produkte = new ArrayList<>();

    public void addProdukt(Produkt produkt) {
        this.produkte.add(produkt);
    }

    public List<String> getProduktNamen() {
        // Aufgabe a)
        return null;
    }

    public List<Double> getUmsaetze() {
        // Aufgabe b)
        return null;
    }

    public List<Produkt> findProdukte(String zeichenImName) {
        // Aufgabe c)
        return null;
    }

    public List<String> getProduktNamenMitVerkaufterMengeKleiner(int verkaufteMenge) {
        // Aufgabe d)
        return null; 
    }
}