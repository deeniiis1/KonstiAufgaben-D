package io.fp;

public class App {
    
    public static void main(String[] args) {
        System.out.println("Frohe Weihnachten und einen guten Rutsch ins neue Jahr!");
    }

}
