package io.fp.container;

public class ElectricalDevices extends Cargo {

    public ElectricalDevices(String name, double weight) {
        super(name, weight);
    }
    
}
