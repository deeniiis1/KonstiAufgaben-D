package io.fp.container;

public class Clothes extends Cargo {

    public Clothes(String name, double weight) {
        super(name, weight );
    }
    
}
