package io.fp.container;

import java.util.ArrayList;

public class Ship {

    ArrayList<Container<? extends Cargo>> registeredContainers = new ArrayList<>();
    private int maxWeight = 30000;
    int currentWeight = 0;

    public ArrayList<Container<? extends Cargo>> registerContainer(ArrayList<Container<? extends Cargo>> containers) {
        for (Container<? extends Cargo> container : containers) {
            currentWeight += container.getCurrentWeight();
            if (currentWeight >= maxWeight) {
                return registeredContainers;
            } else {
                registeredContainers.add(container);
            }
        }
        return registeredContainers;
    }

    public String getRegisteredContainers() {
        return registeredContainers.toString();
    }

}
