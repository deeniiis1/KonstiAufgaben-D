package io.fp.container;

import java.util.ArrayList;

public class Container<T extends Cargo> {

    private ArrayList<T> cargoList;
    private double maxWeight;
    private double currentWeight;

    public Container(ArrayList<T> cargo) {
        this.cargoList = cargo;
        this.maxWeight = 5000;
        this.currentWeight = 2300;
    }

    public Container() {
        this.cargoList = new ArrayList<>();
        this.maxWeight = 5000;
        this.currentWeight = 2300;
    }

    public double getCurrentWeight() {
        return currentWeight;
    }

    public ArrayList<T> getCargo() throws CargoException {
        return cargoList;
    }

    public void loadCargo(T newCargo) throws CargoException {
        if (currentWeight + newCargo.getWeight() > maxWeight) {
            throw new CargoException("the maximum weight was exceeded");
        }
        currentWeight += newCargo.getWeight();
        cargoList.add(newCargo);
        System.out.println("Cargo " + newCargo + " was sucessfully loaded");
    }

    public void unloadContainer() throws CargoException {
        if (cargoList.isEmpty()) {
            throw new CargoException("This conatiner is already empty");
        } else {
            currentWeight = 2300;
            cargoList.clear();
        }
    }

    public void unloadCargo(T requestedCargo) throws CargoException {
        if (cargoList.contains(requestedCargo)) {
            throw new CargoException("The requested cargo s not in this container");
        } else {
            currentWeight -= requestedCargo.getWeight();
            cargoList.remove(requestedCargo);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (T cargo : cargoList) {
            sb.append(cargo.toString()+ "\n");
        }
        return sb.toString();
    }

}
