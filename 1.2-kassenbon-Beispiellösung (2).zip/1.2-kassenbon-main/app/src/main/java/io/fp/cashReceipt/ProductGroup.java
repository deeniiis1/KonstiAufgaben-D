package io.fp.cashReceipt;

public enum ProductGroup {

    VEGETABLES, BEVERAGES, DAIRY, MEAT, HOUSEWARES

}
