package io.fp.cashReceipt;

import java.util.ArrayList;

public class CashRegister {

    private ArrayList<Product> purchase;

    public CashRegister(ArrayList<Product> purchase) {
        this.purchase = purchase;
    }

    public CashRegister() {
        purchase = new ArrayList<>();
    }

    public void scanProduct(Product product) {
        purchase.add(product);
    }

    public double computeTotal(){
        double sum = 0.0;
        for (Product product : purchase) {
            sum+=product.getPrice();
        }
        return sum;
    }

    public void printReceipt() {
        System.out.println("---Receipt---");
        for (ProductGroup pGroup : ProductGroup.values()) {
            System.out.println("---" + pGroup+ "---");
            for (Product product : purchase) {
                if (product.getpGroup().equals(pGroup)) {
                    System.out.println(product.toString());
                }
            }
        }
        System.out.println("Your Total:  " +computeTotal());
    }

}
