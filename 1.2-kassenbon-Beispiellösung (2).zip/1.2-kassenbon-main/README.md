# 1.2 CashReceipt

Für eine Supermarktkasse, soll die Ausgabe eines Kassenbons verbessert werden. Gegeben ist eine Kassenanwendung die bisher sämtliche Produkte gemäß der Reihenfolge, in welcher diese gescannt wurden auf dem Kassenbon druckt. Künftig sollen jedoch Produkte, welche eine gemeinsame Produktgruppe besitzen, untereinander gedruckt werden.

Die Klassen Product und CashRegister sind bereits gegeben. Die Klasse CashRegister, verwaltet eine Liste von Produkten. 


- (a) Ergänzen Sie die Klasse CashRegister um die Methode void scanProduct(Product product), welche das übergebene Produkt der Liste des CashRegisters hinzufügt

- (b) Erstellen Sie für die Produktgruppe einen Aufzählungstyp (enum) namens ProductGroup. Produktgruppen können sein: VEGETABLES, BEVERAGES, DAIRY, MEAT and HOUSEWARES.

- (c) Erweitern Sie die Klasse Product um ein Attribut für die Produktgruppe (ProductGroup pGroup). Implementieren Sie passende Getter-/Setter-Methoden für das neue Attribut und ergänzen Sie das Attribut im Konstruktoren.

- (d) Schreiben Sie zu guter Letzt in der Klasse CashRegister die Methode void printReceipt() so um, dass sie die Produkte der Liste gruppiert nach der Produktgruppe ausgibt. Tipp: Äußere Schleife über die Produktgruppe. Innere Schleife immer über alle Produkte der Liste.

- (e) Erzeugen Sie abschließend in der main-Methode der Klasse App ein paar Produkte und scannen Sie die Produkte mithilfe der von Ihnen geschriebenen Methode. Rufen Sie im Anschluss die Methode printReceipt auf. Die Ausgabe soll z.B. wie folgt aussehen:

![Screenshot](screenshot.PNG)