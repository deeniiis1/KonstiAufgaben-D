package io.fp.marktforschung;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Marktforschung {

    private List<Produkt> produkte = new ArrayList<>();

    public void addProdukt(Produkt produkt) {
        this.produkte.add(produkt);
    }

    public List<String> getProduktNamen() {
        return produkte.stream()
                .map(produkt ->  produkt.getName())
                .collect(Collectors.toList());
    }

    public List<Double> getUmsaetze() {
        return produkte.stream()
                    .map(produkt -> produkt.getPreis() * produkt.getVerkaufteMenge())
                    .collect(Collectors.toList());
    }

    public List<Produkt> findProdukte(String zeichenImName) {
        return produkte.stream()
                    .filter(produkt -> produkt.getName().contains(zeichenImName))
                    .collect(Collectors.toList());
    }

    public List<String> getProduktNamenMitVerkaufterMengeKleiner(int verkaufteMenge) {
        return produkte.stream()
                    .filter(produkt -> produkt.getVerkaufteMenge() < verkaufteMenge)
                    .map(produkt -> produkt.getName())
                    .collect(Collectors.toList());
    }
    
}
