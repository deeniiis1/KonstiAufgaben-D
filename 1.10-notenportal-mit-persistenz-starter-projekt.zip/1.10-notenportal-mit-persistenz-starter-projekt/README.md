# 1.10 Notenportal

Heute erweitern wir das **Notenportal** um eine Speicher- und Ladefunktion.  </br>

**Ziel: Speichern und Laden von Noten**

*Vorgehen: Es sind bereits einige Tests in NotenportalTest vorgegeben. Diese sollen sie nicht verändern. Führen sie sie aus, es sollten zwei fehlschlagen.*

- a) Implementieren sie die Methode **public void save() throws IOException**. </br>
Diese soll eine Datei namens "noten.txt" mit dem Inhalt der Map **noten** erzeugen. </br>
Der Inhalt soll dabei aus Zeilen mit folgendem Format bestehen: NAME_DES_KURSES, NOTE </br>
Beispiel: Fortgeschrittene_Programmierung, 1.3 </br>

- b) Implementieren sie die  Methode **public void load() throws IOException**. </br>
Diese soll die Datei namens "noten.txt" mit dem zuvor geschriebenen Inhalt in die Map **noten** laden. </br>
Das heißt, dass die gelesenen Werte von der Textrepräsentation, wie sie in der Datei steht, in die Objekträpresentation WIF2SemesterKurse und Double umgewandelt werden müssen. </br>
Falls sie die Datei zeilenweise auslesen, können sie die ausgelesene Zeile zunächst mit der Methode **GELESENE_ZEILE.split(",")** in ein Array mit zwei Werten aufteilen. https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/String.html#split(java.lang.String) </br>
Java bietet für viele eingebaute Typen die Funktion aus einem String ein korrespondierendes Objekt zu bauen, so auch für Enum und Double. Nutzen sie für den Kurs die Methode **WIF2SemesterKurse.valueOf(AUFGETEILTER_WERT_0)** und für die Note **Double.parseDouble(AUFGETEILTER_WERT_1)**.

