package io.fp.notenportal;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class Notenportal {
    
    Map<WIF2SemesterKurse, Double> noten = new LinkedHashMap<>();

    public Notenportal() {}

    public void addNote(WIF2SemesterKurse vorlesung, double note)  {
        noten.putIfAbsent(vorlesung, note);
    }

    public double getNote(WIF2SemesterKurse vorlesung) {
        return noten.getOrDefault(vorlesung, 0.0);
    }

    public double calculateSemesterAverage() {
        double notenAverage = 0.0;
        for(var note : noten.values()) {
            notenAverage += note;
        }
        return notenAverage / noten.keySet().size();
    }

    public Set<Entry<WIF2SemesterKurse,Double>> list() {
        return noten.entrySet();
    }

    public void correctNote(WIF2SemesterKurse vorlesung, double note) {
        noten.computeIfPresent(vorlesung, (v, k) -> note);
    }

    public void save() throws IOException {
        //Aufgabe a)
    }

    public void load() throws IOException {
        //Aufgabe b)
    } 

}
