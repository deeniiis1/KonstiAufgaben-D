package io.fp.notenportal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertLinesMatch;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class NotenportalTest {
    
    Notenportal notenportal;

    @BeforeEach
    void setUp() {
        notenportal = new Notenportal();
    }

    @Test
    void single_note_can_be_retrieved() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);

        double note = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.3,  note);
    }

    @Test
    void note_should_be_added_for_fp() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.3, actualNote);
    }

    @Test
    void adding_a_note_multiple_times_for_one_subject_has_no_effect() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.5);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.3, actualNote);
    }

    @Test
    void zero_is_used_as_default_when_note_is_not_set() {
        double note = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(0.0,  note);
    }

    @Test
    void average_is_calculated_from_all_noten() {
        notenportal.addNote(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Computernetzwerke, 1.9);

        double semesterAverage = notenportal.calculateSemesterAverage();

        assertEquals(1.6, semesterAverage, 0.01);
    }

    @Test
    void noten_are_output_in_order() {
        notenportal.addNote(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Computernetzwerke, 1.9);

        Set<Entry<WIF2SemesterKurse,Double>> notenliste = notenportal.list();

        Set<Entry<WIF2SemesterKurse,Double>> expectedNotenliste = new LinkedHashSet<Entry<WIF2SemesterKurse, Double>>();
        expectedNotenliste.add(Map.entry(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6));    
        expectedNotenliste.add(Map.entry(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3));    
        expectedNotenliste.add(Map.entry(WIF2SemesterKurse.Computernetzwerke, 1.9));    
        assertEquals(expectedNotenliste, notenliste);
    }

    @Test
    void note_can_be_corrected_for_a_subject() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.correctNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.5);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.5, actualNote);
    }

    @Test
    void note_cant_be_corrected_if_not_previously_added() {
        notenportal.correctNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.5);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(0, actualNote);
    }

    @Test
    void noten_can_be_saved() throws IOException {
        notenportal.addNote(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Computernetzwerke, 1.9);

        notenportal.save();

        List<String> expectedLines = List.of("Wirtschaftsmathematik, 1.6", "Fortgeschrittene_Programmierung, 1.3", "Computernetzwerke, 1.9");
        assertLinesMatch(expectedLines, Files.readAllLines(Path.of("noten.txt")));
    }

    @Test
    void noten_can_be_loaded() throws IOException {
        notenportal.load();

        Set<Entry<WIF2SemesterKurse,Double>> list = notenportal.list();

        assertEquals(3, list.size());
        assertTrue(list.contains(Map.entry(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6)));
        assertTrue(list.contains(Map.entry(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3)));
        assertTrue(list.contains(Map.entry(WIF2SemesterKurse.Computernetzwerke, 1.9)));
    }

}