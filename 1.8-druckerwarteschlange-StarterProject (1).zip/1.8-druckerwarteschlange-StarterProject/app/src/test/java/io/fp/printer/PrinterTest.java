package io.fp.printer;

public class PrinterTest {
    
}
