# 1.8 Druckerwarteschlange


Die Drucker der Hochschule benötigen eine neue Art, inwiefern Druckaufträge abgearbeitet werden. Genauer handelt es sich um einen Drucker, welcher von sämtlichen Angehörigen der Hochschule (Professoren, Mitarbeitern & Studenten) Kostenfrei genutzt werden kann. Dieser Drucker arbeitet bisher sämtliche Druckaufträge geordnet nach dem Zeitpunkt an welchem Sie aufgegeben wurden sind ab. 
Um jedoch zu vermeiden das Professoren verspätet zu Vorlesungen erscheinen, soll die Reihenfolge in welcher die Druckaufträge in der Warteschlange des Druckers sortiert werden, angepasst werden. Künftig sollen zuerst Aufträge von Professoren, dann Aufträge von Mitarbeitern und abschließend Aufträge von Studenten gedruckt werden.
Es existieren bereits folgende Klassen:

Person:	Diese Klasse repräsentiert einen Angehörigen der Hochschule. Eine Person besitzt in diesem Fall Attribute wie die Emailadresse des Angehörigen und einen Member typ welcher die Rolle der Person innerhalb der Hochschule anzeigt. 

MemberType:	Der Aufzählungstyp besitzt die Werte PROF, EMPLOYEEE und STUDENT. Der MemberType wird verwendet um einem Objekt der Klasse Person seine Rolle zuzuweisen.

PrintJob:	Objekte der Klasse PrintJob repräsentieren einen Druckauftrag. Ein Druckauftrag besteht zum einem aus einem String (printedString), welcher das zu druckende repräsentiert. Und zum anderem aus einer Person welche den Druckauftrag erstellt hat.

Ergänzen Sie nun die Anwendung insofern, dass Druckaufträge gemäß der Ordnung PROF, EMPLOYEE, STUDENT abgearbeitet werden. 

- (a)	Erstellen Sie die Klasse Printer. Der Drucker verfügt über eine Warteschlange (printerQueue) in welcher sämtliche Druckaufträge gespeichert werden. Implementieren hierfür lediglich eine Methode zum Hinzufügen eines Druckauftrags public void addPrintJob(PrintJob pJob) und eine Methode welche sämtliche Druckaufträge der Warteschlange nacheinander auf der Konsole ausgibt public void printAllJobs().

- (b)	Stellen Sie abschließend sicher, dass Ihre Implementierung die bereits erläuterte Druckpriorität berücksichtigt. (Erst PROF, dann EMPLOYEE, dann STUDENT)

- (c)	Kommentieren Sie den Code der Main-Methode aus und führen Sie das Programm aus.
