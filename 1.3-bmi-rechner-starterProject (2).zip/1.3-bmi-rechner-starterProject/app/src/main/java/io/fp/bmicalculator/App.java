package io.fp.bmicalculator;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        HealthCheck healthCheck = new HealthCheck();
        try (Scanner scanner = new Scanner(System.in)) {
            
            boolean continueHealtCheck = true;
            while (continueHealtCheck) {
                System.out.println("------ Start Health Check ------\n");
                System.out.println("Please enter your height in meters:");
                String heightString = scanner.nextLine();
                System.out.println("Please enter your weight in kilograms:");
                String weightString = scanner.nextLine();

                
                    System.out.println(healthCheck.executeHealthCheck(Double.parseDouble(weightString), Double.parseDouble(heightString)));
                    System.out.println("Do you want to execute another health-ckeck? (Y/N)");
                    String answer = scanner.nextLine();
                    if (!answer.equals("Y")) {
                        continueHealtCheck = false;
                    }
            }
        }

    }

}