package io.fp.bmicalculator;

import java.util.ArrayList;

public class HealthCheck {

  private ArrayList<Calculation> history;

  public HealthCheck(){
    this.history = new ArrayList<>();
  }

  public String executeHealthCheck(double weight, double height){
    //Aufgabe c) 
    return null;
  }
  
  public void printAverageBMI() {
    //optimale Aufgabe
  }
  
  public void printHistory() {
    //optimale Aufgabe
  }

  public void printCategoryStatistics() {
    //optimale Aufgabe
  }

  
}
