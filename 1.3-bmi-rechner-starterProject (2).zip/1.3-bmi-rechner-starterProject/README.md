# 1.3 BMI-Rechner

Für den Gesundheitscheck einer Krankenkasse soll eine Anwendung programmiert werden die mithilfe eines BMI-Rechners, die Klassifizierungen des Körpers eines Anwenders berechnet und speichert. Einem Anwender wird demnach die Möglichkeit geboten, durch das eingeben seiner Größe und seines Gewichts, einen BMI-Wert berechnet zu bekommen und seine BMIKategorie zu sehen. Des Weiteren kann ein Anwender eine Historie und Statistiken seiner letzten Berechnungen einsehen. Gegeben sind die folgenden Klassen/Enums: 

- App: Ausführbare Klasse, die einem Benutzer die Berechnung eines BMI über das Terminal ermöglicht. 
- Calculation: Eine Klasse, die eine Berechnung repräsentiert und den BMI sowie die entsprechende Kategorie speichert. 
- Category: Ein Enum, welches die BMI-Kategorien festlegt und einem BMI eine Kategorie zuweisen kann. 
- HealthCheck: Eine Klasse die alle getätigten Berechnungen (Calculation) in einer Liste speichert und diverse Methoden zur Durchführung einer neuen Berechnung, sowie zur Ausgabe gewisser Statistiken bereitstellt. 

Das Projekt ist bereits ausführbar, aber es werden noch keine Berechnungen durchgeführt, keine Daten gespeichert und es sind auch noch nicht alle Statistiken implementiert.  

- (a)	Erstellen Sie zunächst die Exception-Klassen: BMICalculatorException (erweitert java.lang.Exception) und BMICategoryException (erweitert java.lang.RumtimeException), welche später für die Fehlerbehandlung der Anwendung verwendet werden.

- (b)	Nun fehlt noch eine Methode zur Berechnung des BMI. Erstellen Sie daher eine Klasse namens BMICalculator, welche die statische Methode double computeBMI(double weight, double height) throws BMICalculatorException beinhaltet. Die Methode soll für die übergebene Körpergröße und das Gewicht, den BMI berechnen und zurückgeben. Tritt jedoch der Fall auf, dass die übergebenen Werte außerhalb der üblichen Werte für einen Erwachsenen Menschen liegen (d.h. Es wurde eine Körpergröße <1.0 oder >2.4, oder ein Gewicht <30 oder >200 übergeben), soll eine BMICalculatorException, mit der Nachricht: „The values are out of range for a human“, geworfen werden.

- (c)	Vervollständigen Sie nun die Methode public static Category getCategory(double bmi) welche sich im Aufzählungstyp Category befindet. Bisher wird für einen übergebenen BMI lediglich überprüft in welcher Kategorie sich dieser befindet. Nun soll jedoch zusätzlich überprüft werden, ob der übergebene BMI überhaupt einer Kategorie zuzuordnen ist. Lässt sich der Wert, keiner Kategorie zuordnen, so soll eine CategoryException, mit der Nachricht: „This BMI can not be converted into a category“, geworfen werden.

- (d)	Vervollständigen Sie nun die Methode public String executeHealthCheck(double weight, double height) der Klasse HelathCheck. Diese Methode soll zunächst mithilfe des BMICalculator, einen BMI für die übergebenen Werte berechnen (Aufruf der Methode aus Teilaufgabe a)). Anschließend soll ein Calculation-Objekt mit diesem BMI und der dazugehörigen Kategorie erstellt werden und der Liste history hinzugefügt werden. Abschließend kann nun das Calculation-Objekt als String zurückgegeben werden (Hinweis: Vrewendung der toString()-Methode).

Hinweis: Verwenden Sie folgenden Befehl um die Anwendung ohne den Ladebalken auszuführen: gradle run --console=plain
