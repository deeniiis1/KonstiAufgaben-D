package io.fp.printer;

import java.util.PriorityQueue;

public class Printer {

    private PriorityQueue<PrintJob> printerQueue;

    public Printer() {
        this.printerQueue = new PriorityQueue<>();
    }

    public void addPrintJob(PrintJob pJob) {
        printerQueue.add(pJob);
    }

    public PrintJob getNextPrintJob(){
        return printerQueue.poll();
    }

    public void printJobs() {
        while (!printerQueue.isEmpty()) {
            System.out.println(printerQueue.poll() + "\n");
        }
    }
}
