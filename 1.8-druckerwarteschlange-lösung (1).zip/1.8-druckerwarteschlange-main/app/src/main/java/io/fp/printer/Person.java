package io.fp.printer;

public class Person {
    
    private String email;
    private MemberType memberType;

    public Person(String email, MemberType memberType) {
        this.email = email;
        this.memberType = memberType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public MemberType getMemberType() {
        return memberType;
    }

    public void setMemberType(MemberType memberType) {
        this.memberType = memberType;
    }

    @Override
    public String toString() {
        return email + " with role: " + memberType;
    }
}
