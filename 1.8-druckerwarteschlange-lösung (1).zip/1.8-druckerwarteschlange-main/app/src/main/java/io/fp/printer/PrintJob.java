package io.fp.printer;

public class PrintJob implements Comparable<PrintJob> {

    private String printedString;
    private Person person;

    public PrintJob(String printedString, Person person) {
        this.printedString = printedString;
        this.person = person;
    }

    @Override
    public String toString() {
        return person + ", printed= " + printedString;
    }

    @Override
    public int compareTo(PrintJob other) {
        // return
        // this.person.getMemberType().compareTo(other.getPerson().getMemberType());
        if (this.person.getMemberType().equals(other.person.getMemberType())) {
            return 0;
        } else if (other.person.getMemberType().equals(MemberType.PROF)) {
            return 1;
        } else if (other.person.getMemberType().equals(MemberType.EMPLOYEE)
                && this.person.getMemberType().equals(MemberType.STUDENT)) {
            return 1;
        } else {
            return -1;
        }
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getPrintedString() {
        return printedString;
    }

    public void setPrintedString(String printedString) {
        this.printedString = printedString;
    }

}
