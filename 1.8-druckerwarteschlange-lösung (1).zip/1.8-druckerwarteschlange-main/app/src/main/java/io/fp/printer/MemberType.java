package io.fp.printer;

public enum MemberType {
    PROF, EMPLOYEE, STUDENT;
}
