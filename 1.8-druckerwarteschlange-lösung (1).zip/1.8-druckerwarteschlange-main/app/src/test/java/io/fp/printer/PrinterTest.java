package io.fp.printer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class PrinterTest {

    @Test
    void testPrinterQueue() {
        Printer printer = new Printer();
        PrintJob pJob1 = new PrintJob("This was printed by an Student", new Person("Student@mail.com", MemberType.STUDENT));
        PrintJob pJob2 = new PrintJob("This was printed by an Employee",new Person("Employee@mail.com", MemberType.EMPLOYEE));
        PrintJob pJob3 = new PrintJob("This was printed by an Prof", new Person("Prof@mail.com", MemberType.PROF));
        printer.addPrintJob(pJob1);
        printer.addPrintJob(pJob2);
        printer.addPrintJob(pJob3);

        assertEquals(pJob3, printer.getNextPrintJob());
    }
}
