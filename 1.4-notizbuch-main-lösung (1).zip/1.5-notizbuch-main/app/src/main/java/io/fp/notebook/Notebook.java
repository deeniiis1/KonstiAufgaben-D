package io.fp.notebook;

import java.util.ArrayList;

public class Notebook<T> {
    ArrayList<T> noteList = new ArrayList<>();

    public void addNote(T note) {
        noteList.add(note);
    }

    public int getNumberOfNotes() {
        return noteList.size();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("------Notebook-----"+ System.lineSeparator());

        for (T n : noteList) {
            sb.append(n.toString()+ System.lineSeparator());
        }
        sb.append("-------------------" + System.lineSeparator());

        return sb.toString();
    }

}
