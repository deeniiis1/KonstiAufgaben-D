package io.fp.notebook;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class NotebookTest {

    Notebook<String> notebook;

    @BeforeEach
    void setup() {
        notebook=new Notebook<>();
        notebook.addNote("Learn gradle");
    }

    @Test
    void testAddNote() {
        int non = notebook.getNumberOfNotes();
        notebook.addNote("Learn Java");
        assertEquals(non+1, notebook.getNumberOfNotes());
    }   
}

