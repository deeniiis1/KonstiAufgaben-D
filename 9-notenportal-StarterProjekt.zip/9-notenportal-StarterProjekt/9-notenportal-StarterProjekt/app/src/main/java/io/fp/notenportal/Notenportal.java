package io.fp.notenportal;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class Notenportal {
    
    Map<WIF2SemesterKurse, Double> noten = new LinkedHashMap<>();

    public Notenportal() {}

    // Aufgabe a)
    public void addNote(WIF2SemesterKurse vorlesung, double note)  {
    }

    // Aufgabe b)
    public double getNote(WIF2SemesterKurse vorlesung) {
        return noten.get(vorlesung);
    }

    // Aufgabe c)
    public double calculateSemesterAverage() {
        return Double.NaN;
    }

    //  Aufgabe d)
    public Set<Entry<WIF2SemesterKurse,Double>> list() {
    }

    // Aufgabe e)
    public void correctNote(WIF2SemesterKurse vorlesung, double note) {
    }

}
