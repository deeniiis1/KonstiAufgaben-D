package io.fp.notenportal;

public enum WIF2SemesterKurse {
    Computernetzwerke, Fortgeschrittene_Programmierung, Wirtschaftsmathematik
}
