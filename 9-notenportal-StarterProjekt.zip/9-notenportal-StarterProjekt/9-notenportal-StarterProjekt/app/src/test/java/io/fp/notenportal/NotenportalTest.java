package io.fp.notenportal;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class NotenportalTest {
    
    Notenportal notenportal;

    @BeforeEach
    void setUp() {
        notenportal = new Notenportal();
    }

    // Aufgabe a)
    @Test
    void note_should_be_added_for_fp() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.3, actualNote);
    }

    // Aufgabe a)
    @Test
    void adding_a_note_multiple_times_for_one_subject_has_no_effect() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.5);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.3, actualNote);
    }

    @Test
    void single_note_can_be_retrieved() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);

        double note = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.3,  note);
    }

    // Aufgabe b)
    @Test
    void zero_is_used_as_default_when_note_is_not_set() {
        double note = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(0.0,  note);
    }

    // Aufgabe c)
    @Test
    void average_is_calculated_from_all_noten() {
        notenportal.addNote(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Computernetzwerke, 1.9);

        double semesterAverage = notenportal.calculateSemesterAverage();

        assertEquals(1.6, semesterAverage, 0.01);
    }

    // Aufgabe d)
    @Test
    void noten_are_output_in_order_of_entry() {
        notenportal.addNote(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6);
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.addNote(WIF2SemesterKurse.Computernetzwerke, 1.9);

        Set<Entry<WIF2SemesterKurse,Double>> notenliste = notenportal.list();

        Set<Entry<WIF2SemesterKurse,Double>> expectedNotenliste = new LinkedHashSet<Entry<WIF2SemesterKurse, Double>>();
        expectedNotenliste.add(Map.entry(WIF2SemesterKurse.Wirtschaftsmathematik, 1.6));    
        expectedNotenliste.add(Map.entry(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3));    
        expectedNotenliste.add(Map.entry(WIF2SemesterKurse.Computernetzwerke, 1.9));    
        assertEquals(expectedNotenliste, notenliste);
    }

    // Aufgabe e)
    @Test
    void note_can_be_corrected_for_a_subject() {
        notenportal.addNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.3);
        notenportal.correctNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.5);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(1.5, actualNote);
    }

    // Aufgabe e)
    @Test
    void note_cant_be_corrected_if_not_previously_added() {
        notenportal.correctNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung, 1.5);

        double actualNote = notenportal.getNote(WIF2SemesterKurse.Fortgeschrittene_Programmierung);

        assertEquals(0, actualNote);
    }

}