# 1.9 Notenportal

Heute bauen wir ein **Notenportal** für das zweite Semester.  </br>
In diesem Notenportal sollen Noten für  verschiedene Kurse eingetragen und korrigiert werden können.  </br>
Außerdem soll auch der Notendurschnitt ausgerechnet und die Gesamtsicht ausgegeben werden können. </br>

**Ziel: Kennenlernen der  Maps API**

*Vorgehen: Es sind bereits einige Tests in NotenportalTest vorgegeben. Diese sollen sie nicht verändern, außer sie werden in der Aufgabe dazu aufgefordert. Arbeiten sie sich von einem Test zum Nächsten.*

- a) Führen sie die Tests aus. Es sollten alle feschlagen. </br>
  Als erstes benötigen wir eine Funktionalität, dass eine Note für eine Vorlesung eingetragen werden kann.
  Programmieren sie hierzu die Methode void **addNote**, die es erlauben soll eine Note für einen Kurs einmalig hinzuzufügen. Wird die Methode für denselben Kurs weitere Male aufgerufen, soll der Aufruf ignoriert werden, da hierfür später die Methode **correctNote** programmiert wird.

- b) Damit die Noten auch einzeln abgefragt werden können gibt es bereits die **getNote** Methode. Ergänzen sie nun die Logik, dass bei Abfrage einer fehlenden Note nie **null**, sondern der Defaultwert 0.0 zurückgegeben wird.

- c) Die Durchschnittsnote des Semesters soll ausgegeben werden können. Programmieren sie hierzu die Methode **calculateSemesterAverage** aus. </br>

- d) Um eine Liste aller Kurse und erlangter Noten zu bekommen soll die Methode **list** ausprogrammiert werden. </br>
    Dort sollen alle Einträge der Notenliste als Key-Value-Pair zurückgegeben werden. </br> </br>
    Nachdem der Test erfolgreich durchläuft, passen sie den Test auf eine neue Anforderung an:  </br>
    Die Notenliste soll nun alphabetisch nach Kursnamen sortiert sein. </br>
    Sobald der Test fehlschlägt passen sie die Implementierung in Notenportal an der passenden Stelle an, um den Test wieder grün zu bekommen.

- e) Zuletzt soll es die Möglichkeit geben eingetragene Noten mit der Methode **correctNote** zu korrigieren.
    Außerdem soll diese Methode **NUR** zum Korrigieren genutzt werden, d.h. wenn für einen Kurs eine Note noch nicht eingetragen wurde, soll die Methode auch nichts machen.

- f) Sobald sie mit der gesamten Implementierung fertig sind können sie in der App.java ihren Namen für die Variable name setzen und ihre Notenansicht durch Ausführen der main anzeigen lassen.

