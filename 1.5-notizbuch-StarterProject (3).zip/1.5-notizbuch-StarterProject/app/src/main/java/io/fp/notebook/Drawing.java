package io.fp.notebook;

public class Drawing {

    public String drawing;

    public Drawing(String drawing) {
        this.drawing = drawing;
    }

    public String drawSomething() {
        StringBuilder sb = new StringBuilder();
        sb.append("   /\\   \n"); 
        sb.append("  /  \\  \n"); 
        sb.append(" /    \\ \n"); 
        sb.append(drawing + "\n"); 
        sb.append(" \\    / \n"); 
        sb.append("  \\  /  \n"); 
        sb.append("   \\/   \n");

        return sb.toString();
    }

    @Override
    public String toString() {
        return drawSomething();
    }

}