# 1.5 Notizbuch

Gegeben ist die Anwendung Notebook (Notizbuch). Das Java Programm dient dem Organisieren von Notizen. Das generische Notizbuch soll hierbei verschiedenste Arten von Notizen speichern können, sowie beispielsweise Zahlen, Zeichenketten, Skizzen etc. Die vorgegebenen Klassen IntelligentNote und Drawing zeigen Beispiele möglicher Notiztypen. Eine intelligente Notiz (IntelligentNote) kann neben der eigentlichen Notiz eine Priorität und ein Fälligkeitsdatum speichern. Eine Skizze (Drawing) soll hingegen eine Zeichnung repräsentieren, wie man sie beispielsweise in ein Skizzenbuch schreiben würde. Ergänzen Sie die Anwendung um die fehlende generische Klasse Notebook.

- (a) Die generische Klasse Notebook, soll dazu in der Lage seine sämtlichen Notizen, unabhängig von Ihrem Typ, in einer Liste zu speichern. Schreiben Sie eine Methode zum Hinzufügen einer Notiz (addNote), sowie eine Methode, die die Anzahl der Notizen im Notizbuch zurückgibt (getNumberOfNotes). 

- (b) Überschreiben Sie anschließend die toString()-Methode unter Verwendung der Klasse StringBuilder (https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html), so dass die einzelnen Notizen des Notizbuches untereinander auf der Konsole ausgegeben werden können.

- (c) Erstellen Sie abschließend zwei Notizbücher innerhalb der App Klasse. Ein Notizbuch soll mit Notizen vom Typ IntelligentNote arbeiten und das andere mit Notizen vom Typ Drawing. Fügen Sie den Notizbüchern mindestens drei Notizen hinzu und geben Sie die Notizbücher mittels System.out.println auf der Konsole aus.